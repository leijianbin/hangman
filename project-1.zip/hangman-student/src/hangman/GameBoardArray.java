package hangman;

/**
 * The Array implementation of the GameBoard interface.
 */
public class GameBoardArray implements GameBoard, HangManConstants {
	/** The number of characters (lower/upper). */
	private static int ALPHABET_COUNT = 26*2;
	
	/** hung state */
	private int		state;
	
	/**
	 * Creates a new GameBoardArray object.
	 * 
	 *  guessWord the word to guess
	 */
	public GameBoardArray(String guessWord) {
		// TODO (1)
		state    = STARTING_STATE;
	}
		
	public boolean isPriorGuess(char guess) {
		// TODO (2)
		return false;
	}
	
	public int numberOfGuesses() {
		// TODO (3)
		return 0;
	}
	
	public boolean isCorrectGuess(char guess) {
		// TODO (4)
		return false;
	}
	
	public boolean doMove(char guess) {
		// TODO (5)
		return false;
	}

	public boolean inWinningState() {
		// TODO (6)
		return false;
	}

	public boolean inLosingState() {
		return state == NUMBER_OF_STATES;
	}
	
	public String toString() {
		String s = "";
		
		// TODO (7)
		
		return s;
	}

	public String previousGuessString() {
		String s = "";
		 
		// TODO (8)
		
		return s;
	}
	
	public int currentHungState() {
		return state;
	}

}
