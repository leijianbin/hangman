package hangman;

/**
 * Useful constants used in the game.
 */
public interface HangManConstants {
	public static int NUMBER_OF_STATES = 10;
	public static int STARTING_STATE   = 0;
}
