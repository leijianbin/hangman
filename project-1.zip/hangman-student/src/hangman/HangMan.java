package hangman;


public interface HangMan extends HangManConstants {	
	public void display(int state);
}
